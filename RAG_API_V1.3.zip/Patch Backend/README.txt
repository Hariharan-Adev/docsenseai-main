Backend patch for same-domain /api compatibility

Copy these files into the matching paths on the server backend project:

1. backend/src/app/main.py
   Target path: <server-backend-root>/src/app/main.py

2. backend/tests/test_auth_password_reset.py
   Target path: <server-backend-root>/tests/test_auth_password_reset.py

3. backend/tests/test_projects.py
   Target path: <server-backend-root>/tests/test_projects.py

What changed:
- The backend now accepts same-domain /api routes such as /api/auth/login,
  /api/projects, /api/health, /api/chat, and /api/search.
- Existing unprefixed routes such as /auth/login and /projects still work.

After copying, restart the FastAPI backend service.

Recommended server checks:
curl -i http://127.0.0.1:8000/api/health
curl -i http://127.0.0.1:8000/api/projects

Expected:
- /api/health should not return 404.
- /api/projects should not return 404. Without login token, 401/403 is acceptable.
